# Developer Productivity MVP

A focused full-stack MVP for the intern assignment. It converts raw engineering metrics into an IC story and practical next steps.

## What this app shows

- Individual Contributor profile view
- 5 assignment metrics:
  - Lead Time for Changes
  - Cycle Time
  - Bug Rate
  - Deployment Frequency
  - PR Throughput
- Interpretation of the likely bottleneck
- 1-2 practical next steps
- Lightweight manager summary page/section

## Tech stack

- Frontend: React.js + Vite
- Backend: Node.js + Express
- Data: Provided Excel workbook converted into JSON

## Folder structure

```text
dev-productivity-mvp/
  client/              React frontend
  server/              Express backend
  server/data/         JSON data extracted from workbook
```

## How to run

### 1. Install Node.js
Use Node.js version 18 or above.

Check version:

```bash
node -v
npm -v
```

### 2. Open the project folder

```bash
cd dev-productivity-mvp
```

### 3. Install dependencies

```bash
npm run install-all
```

### 4. Run backend and frontend together

```bash
npm run dev
```

### 5. Open the app

Open this in your browser:

```text
http://localhost:5173
```

Backend API runs here:

```text
http://localhost:4000/api
```

## Separate run option

Terminal 1:

```bash
cd dev-productivity-mvp/server
npm install
npm run dev
```

Terminal 2:

```bash
cd dev-productivity-mvp/client
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## API endpoints

```text
GET /api/health
GET /api/options
GET /api/developers/:developerId?month=2026-04
GET /api/manager-summary?month=2026-04
```

## Metric logic used

- Lead Time = average `lead_time_days` from successful production deployments in the selected month
- Cycle Time = average `cycle_time_days` from completed Jira issues in the selected month
- Bug Rate = escaped production bugs / completed issues
- Deployment Frequency = count of successful production deployments
- PR Throughput = count of merged PRs

## Demo video flow

1. Explain the problem: metrics alone do not tell the developer what to do next.
2. Show the IC dashboard.
3. Select Noah Patel and April 2026.
4. Explain each metric card.
5. Explain the generated story.
6. Explain recommended next steps.
7. Show manager summary.
8. Explain responsible AI use: AI helped structure and debug, but metric logic is simple and explainable.
