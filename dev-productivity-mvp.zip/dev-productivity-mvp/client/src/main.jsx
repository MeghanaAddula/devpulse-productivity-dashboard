import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Activity, AlertTriangle, CheckCircle2, GitPullRequest, Rocket, Search, Users } from 'lucide-react';
import { getDeveloperSnapshot, getManagerSummary, getOptions } from './api.js';
import './styles.css';

const metricCards = snapshot => [
  { label: 'Lead Time', value: `${snapshot.metrics.leadTime} days`, help: 'PR opened → production deployment', icon: Rocket, status: snapshot.metrics.leadTime >= 4 ? 'warn' : 'good' },
  { label: 'Cycle Time', value: `${snapshot.metrics.cycleTime} days`, help: 'In Progress → Done', icon: Activity, status: snapshot.metrics.cycleTime >= 5 ? 'warn' : 'good' },
  { label: 'Bug Rate', value: `${Math.round(snapshot.metrics.bugRate * 100)}%`, help: 'Escaped bugs / issues done', icon: AlertTriangle, status: snapshot.metrics.bugRate >= 0.5 ? 'danger' : 'good' },
  { label: 'Deployments', value: snapshot.metrics.deploymentFrequency, help: 'Successful prod deployments', icon: Rocket, status: snapshot.metrics.deploymentFrequency < 2 ? 'warn' : 'good' },
  { label: 'PR Throughput', value: snapshot.metrics.prThroughput, help: 'Merged PRs in month', icon: GitPullRequest, status: snapshot.metrics.prThroughput < 2 ? 'warn' : 'good' }
];

function App() {
  const [options, setOptions] = useState(null);
  const [developerId, setDeveloperId] = useState('DEV-002');
  const [month, setMonth] = useState('2026-04');
  const [snapshot, setSnapshot] = useState(null);
  const [managerSummary, setManagerSummary] = useState([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getOptions().then(data => {
      setOptions(data);
      setDeveloperId(data.developers[1]?.id || data.developers[0]?.id);
      setMonth(data.months[data.months.length - 1]);
    });
  }, []);

  useEffect(() => {
    if (!developerId || !month) return;
    setLoading(true);
    Promise.all([getDeveloperSnapshot(developerId, month), getManagerSummary(month)])
      .then(([dev, managers]) => {
        setSnapshot(dev);
        setManagerSummary(managers);
      })
      .finally(() => setLoading(false));
  }, [developerId, month]);

  const filteredDevelopers = useMemo(() => {
    if (!options) return [];
    return options.developers.filter(dev => `${dev.name} ${dev.team} ${dev.level}`.toLowerCase().includes(query.toLowerCase()));
  }, [options, query]);

  if (!options || !snapshot) return <main className="loading">Loading MVP data...</main>;

  return (
    <main className="app-shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Developer Productivity MVP</p>
          <h1>Move from raw metrics to better developer actions.</h1>
          <p className="hero-copy">This prototype reads Jira-like issues, pull requests, deployments, and bug reports. It explains the likely story behind the metrics and recommends practical next steps.</p>
        </div>
        <div className="hero-panel">
          <span>Focused journey</span>
          <strong>IC profile → interpretation → next steps</strong>
          <small>Manager summary added as a lightweight extension.</small>
        </div>
      </section>

      <section className="controls-card">
        <label>
          Select month
          <select value={month} onChange={event => setMonth(event.target.value)}>
            {options.months.map(item => <option key={item}>{item}</option>)}
          </select>
        </label>
        <label className="search-box">
          Search developer
          <div>
            <Search size={16} />
            <input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search by name, team, level" />
          </div>
        </label>
        <label>
          Select developer
          <select value={developerId} onChange={event => setDeveloperId(event.target.value)}>
            {filteredDevelopers.map(dev => <option key={dev.id} value={dev.id}>{dev.name} · {dev.team}</option>)}
          </select>
        </label>
      </section>

      {loading ? <section className="loading-card">Refreshing insights...</section> : <Dashboard snapshot={snapshot} />}

      <section className="manager-section">
        <div className="section-heading">
          <Users size={20} />
          <div>
            <h2>Manager summary</h2>
            <p>Simple team-level view for spotting bottlenecks without judging developers blindly.</p>
          </div>
        </div>
        <div className="manager-grid">
          {managerSummary.map(manager => <ManagerCard key={manager.managerId} manager={manager} />)}
        </div>
      </section>
    </main>
  );
}

function Dashboard({ snapshot }) {
  const cards = metricCards(snapshot);
  return (
    <section className="dashboard-grid">
      <div className="profile-card">
        <p className="eyebrow">Selected IC</p>
        <h2>{snapshot.developerName}</h2>
        <p>{snapshot.level} · {snapshot.serviceType} · {snapshot.teamName}</p>
        <div className="profile-meta">
          <span>Manager: {snapshot.managerName}</span>
          <span>Month: {snapshot.month}</span>
        </div>
      </div>

      <div className="metrics-grid">
        {cards.map(card => <MetricCard key={card.label} card={card} />)}
      </div>

      <div className="story-card">
        <div className="section-heading compact">
          <CheckCircle2 size={20} />
          <div>
            <h2>Likely story</h2>
            <p>Interpretation generated from metric thresholds.</p>
          </div>
        </div>
        <p className="story-text">{snapshot.insight}</p>
        <div className="debug-row">
          <span>Review wait: {snapshot.metrics.avgReviewWaitHours} hrs</span>
          <span>Merge time: {snapshot.metrics.avgMergeTimeHours} hrs</span>
          <span>Avg PR size: {snapshot.metrics.avgLinesChanged} lines</span>
        </div>
      </div>

      <div className="actions-card">
        <h2>Recommended next steps</h2>
        <ol>
          {snapshot.nextSteps.map(step => <li key={step}>{step}</li>)}
        </ol>
      </div>
    </section>
  );
}

function MetricCard({ card }) {
  const Icon = card.icon;
  return (
    <article className={`metric-card ${card.status}`}>
      <div className="metric-top">
        <Icon size={20} />
        <span>{card.label}</span>
      </div>
      <strong>{card.value}</strong>
      <small>{card.help}</small>
    </article>
  );
}

function ManagerCard({ manager }) {
  return (
    <article className="manager-card">
      <div>
        <h3>{manager.managerName}</h3>
        <p>{manager.teamName} · {manager.teamSize} developers</p>
      </div>
      <span className={manager.signal === 'Healthy flow' ? 'pill good-pill' : 'pill warn-pill'}>{manager.signal}</span>
      <div className="manager-metrics">
        <span>Lead: <b>{manager.avgLeadTime}</b>d</span>
        <span>Cycle: <b>{manager.avgCycleTime}</b>d</span>
        <span>Bug rate: <b>{Math.round(manager.avgBugRate * 100)}%</b></span>
        <span>PRs: <b>{manager.totalPrs}</b></span>
      </div>
    </article>
  );
}

createRoot(document.getElementById('root')).render(<App />);
