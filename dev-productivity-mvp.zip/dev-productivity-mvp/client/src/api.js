const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';

export async function getOptions() {
  const response = await fetch(`${API_BASE}/options`);
  if (!response.ok) throw new Error('Failed to load options');
  return response.json();
}

export async function getDeveloperSnapshot(developerId, month) {
  const response = await fetch(`${API_BASE}/developers/${developerId}?month=${month}`);
  if (!response.ok) throw new Error('Failed to load developer snapshot');
  return response.json();
}

export async function getManagerSummary(month) {
  const response = await fetch(`${API_BASE}/manager-summary?month=${month}`);
  if (!response.ok) throw new Error('Failed to load manager summary');
  return response.json();
}
