import express from 'express';
import cors from 'cors';
import { getDeveloperSnapshot, getHealth, getManagerSummary, getOptions } from './metrics.js';

const app = express();
const port = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json(getHealth()));
app.get('/api/options', (req, res) => res.json(getOptions()));
app.get('/api/developers/:developerId', (req, res) => {
  const month = req.query.month || '2026-04';
  res.json(getDeveloperSnapshot(req.params.developerId, month));
});
app.get('/api/manager-summary', (req, res) => {
  const month = req.query.month || '2026-04';
  res.json(getManagerSummary(month));
});

app.listen(port, () => console.log(`Developer Productivity API running on http://localhost:${port}`));
