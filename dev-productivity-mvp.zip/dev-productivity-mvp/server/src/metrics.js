import workbook from '../data/workbook-data.json' with { type: 'json' };

const developers = workbook.Dim_Developers;
const issues = workbook.Fact_Jira_Issues;
const prs = workbook.Fact_Pull_Requests;
const deployments = workbook.Fact_CI_Deployments;
const bugs = workbook.Fact_Bug_Reports;

const round = (value, digits = 2) => Number.isFinite(value) ? Number(value.toFixed(digits)) : 0;
const avg = items => items.length ? items.reduce((sum, item) => sum + Number(item || 0), 0) / items.length : 0;
const unique = items => [...new Set(items.filter(Boolean))];

function developerBase(developerId) {
  return developers.find(dev => dev.developer_id === developerId);
}

function availableMonths() {
  return unique([
    ...issues.map(item => item.month_done),
    ...prs.map(item => item.month_merged),
    ...deployments.map(item => item.month_deployed),
    ...bugs.map(item => item.month_found)
  ]).sort();
}

function calculateDeveloperMonth(developerId, month) {
  const dev = developerBase(developerId);
  const monthIssues = issues.filter(item => item.developer_id === developerId && item.month_done === month && item.status === 'Done');
  const monthPrs = prs.filter(item => item.developer_id === developerId && item.month_merged === month && item.status === 'merged');
  const monthDeployments = deployments.filter(item => item.developer_id === developerId && item.month_deployed === month && item.environment === 'prod' && item.status === 'success');
  const monthBugs = bugs.filter(item => item.developer_id === developerId && item.month_found === month && item.escaped_to_prod === 'Yes');

  const metrics = {
    issuesDone: monthIssues.length,
    prThroughput: monthPrs.length,
    deploymentFrequency: monthDeployments.length,
    escapedBugs: monthBugs.length,
    cycleTime: round(avg(monthIssues.map(item => item.cycle_time_days))),
    leadTime: round(avg(monthDeployments.map(item => item.lead_time_days))),
    bugRate: monthIssues.length ? round(monthBugs.length / monthIssues.length, 2) : 0,
    avgReviewWaitHours: round(avg(monthPrs.map(item => item.review_wait_hours)), 1),
    avgMergeTimeHours: round(avg(monthPrs.map(item => item.merge_time_hours)), 1),
    avgLinesChanged: Math.round(avg(monthPrs.map(item => item.lines_changed))),
    avgReviewRounds: round(avg(monthPrs.map(item => item.review_rounds)), 1)
  };

  return {
    developerId,
    developerName: dev?.developer_name || developerId,
    managerId: dev?.manager_id,
    managerName: dev?.manager_name,
    teamName: dev?.team_name,
    serviceType: dev?.service_type,
    level: dev?.level,
    month,
    metrics,
    insight: buildInsight(metrics),
    nextSteps: buildNextSteps(metrics),
    rawCounts: {
      jiraIssues: monthIssues.length,
      pullRequests: monthPrs.length,
      deployments: monthDeployments.length,
      bugs: monthBugs.length
    }
  };
}

function buildInsight(metrics) {
  if (metrics.bugRate >= 0.5) {
    return 'Quality risk is the main signal. Escaped bugs are high compared with completed work, so the next action should focus on testing and release safeguards.';
  }
  if (metrics.cycleTime >= 5 && metrics.avgReviewWaitHours >= 20) {
    return 'Work is moving, but feedback is slow. Cycle time and review wait time suggest the bottleneck is likely during PR review.';
  }
  if (metrics.leadTime >= 4 && metrics.deploymentFrequency <= 2) {
    return 'Code reaches production slower than ideal. The likely bottleneck is deployment/release waiting time after code is merged.';
  }
  if (metrics.prThroughput >= 2 && metrics.deploymentFrequency >= 2 && metrics.bugRate === 0) {
    return 'Delivery flow looks healthy. Work is moving through PR and deployment with no escaped production bugs in this month.';
  }
  return 'No single serious risk stands out, but the data should be watched for review delays, release delays, or quality issues.';
}

function buildNextSteps(metrics) {
  if (metrics.bugRate >= 0.5) {
    return [
      'Add one quality checkpoint before release, such as regression testing for the changed area.',
      'Review escaped bug root causes and convert repeated patterns into checklist items.'
    ];
  }
  if (metrics.cycleTime >= 5 && metrics.avgReviewWaitHours >= 20) {
    return [
      'Split large tickets or PRs into smaller reviewable changes.',
      'Ask for an early reviewer before code is fully complete to reduce waiting time.'
    ];
  }
  if (metrics.leadTime >= 4 && metrics.deploymentFrequency <= 2) {
    return [
      'Separate review delay from deployment delay and check where the PR waits longest.',
      'Batch fewer changes per release or schedule a smaller production deployment.'
    ];
  }
  return [
    'Keep PR size small and continue monitoring lead time, cycle time, and bugs together.',
    'Use the current month as a baseline and compare the next month against it.'
  ];
}

function calculateManagerMonth(managerId, month) {
  const teamDevelopers = developers.filter(dev => dev.manager_id === managerId);
  const snapshots = teamDevelopers.map(dev => calculateDeveloperMonth(dev.developer_id, month));
  const manager = teamDevelopers[0];
  const avgLead = round(avg(snapshots.map(item => item.metrics.leadTime)));
  const avgCycle = round(avg(snapshots.map(item => item.metrics.cycleTime)));
  const avgBugRate = round(avg(snapshots.map(item => item.metrics.bugRate)));
  const totalPrs = snapshots.reduce((sum, item) => sum + item.metrics.prThroughput, 0);
  const totalDeployments = snapshots.reduce((sum, item) => sum + item.metrics.deploymentFrequency, 0);

  return {
    managerId,
    managerName: manager?.manager_name || managerId,
    month,
    teamName: manager?.team_name,
    teamSize: teamDevelopers.length,
    avgLeadTime: avgLead,
    avgCycleTime: avgCycle,
    avgBugRate,
    totalPrs,
    totalDeployments,
    signal: avgBugRate >= 0.3 || avgCycle >= 5 || avgLead >= 4 ? 'Watch bottlenecks' : 'Healthy flow',
    developers: snapshots
  };
}

export function getOptions() {
  return {
    months: availableMonths(),
    developers: developers.map(dev => ({
      id: dev.developer_id,
      name: dev.developer_name,
      team: dev.team_name,
      manager: dev.manager_name,
      level: dev.level
    })),
    managers: developers.reduce((acc, dev) => {
      if (!acc.some(item => item.id === dev.manager_id)) {
        acc.push({ id: dev.manager_id, name: dev.manager_name, team: dev.team_name });
      }
      return acc;
    }, [])
  };
}

export function getDeveloperSnapshot(developerId, month) {
  return calculateDeveloperMonth(developerId, month);
}

export function getManagerSummary(month) {
  const managerIds = unique(developers.map(dev => dev.manager_id));
  return managerIds.map(managerId => calculateManagerMonth(managerId, month));
}

export function getHealth() {
  return {
    status: 'ok',
    sourceTables: Object.keys(workbook),
    records: Object.fromEntries(Object.entries(workbook).map(([key, value]) => [key, value.length]))
  };
}
