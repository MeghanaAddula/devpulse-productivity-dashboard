# 5-10 Minute Demo Script

Hi, my name is Meghana. This is my Developer Productivity MVP.

The problem is that developers and managers can already see metrics like lead time, cycle time, deployment frequency, bug rate, and PR throughput. But raw metrics alone do not explain what is happening or what action the developer should take next.

So I built a focused MVP for one main user journey: Individual Contributor profile, then metric interpretation, then practical next steps.

On this page, the user can select a month and a developer. The app uses the provided workbook data, including Jira-like issues, pull requests, CI deployments, bug reports, and developer details.

For the selected developer, I show the five assignment metrics. Lead time is calculated from successful production deployments. Cycle time is calculated from completed Jira issues. Bug rate is escaped production bugs divided by completed issues. Deployment frequency is successful production deployments. PR throughput is merged pull requests.

The most important part is not the cards. The important part is the interpretation section. Here, the app explains the likely story behind the numbers. For example, if cycle time and review wait time are high, the app says review delay may be the bottleneck. If bug rate is high, it says quality risk is the main signal. If lead time is high and deployments are low, it says deployment waiting time may be the bottleneck.

Then the app gives practical next steps. These are intentionally small and realistic, such as splitting large PRs, asking for early review, adding regression testing, or checking whether delay is happening before or after merge.

I also added a lightweight manager summary. This is not a heavy dashboard. It gives managers a quick view of team health, average lead time, cycle time, bug rate, total PRs, and whether bottlenecks should be watched.

For the backend, I used Node.js and Express. The workbook data is converted to JSON. The backend calculates metrics and returns clean API responses. For the frontend, I used React with reusable components for metric cards, IC story, next steps, and manager cards.

My design choice was to keep the scope small but complete. I focused on clarity, explainability, and action instead of building a broad unfinished dashboard.

AI was used responsibly to understand the assignment, plan the architecture, and speed up scaffolding. But the metric logic is simple, visible, and something I can explain clearly.
